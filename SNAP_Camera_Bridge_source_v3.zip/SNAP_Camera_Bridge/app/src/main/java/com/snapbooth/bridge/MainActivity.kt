package com.snapbooth.bridge

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var addressText: TextView
    private lateinit var server: BridgeHttpServer
    private var imageCapture: ImageCapture? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val frameStore = LatestFrameStore()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        server = BridgeHttpServer(8765, frameStore) { callback ->
            runOnUiThread { callback() }
        }
        CaptureRegistry.handler = { callback -> captureJpeg(callback) }
        try {
            server.start()
        } catch (e: Exception) {
            statusText.text = "Server gagal dimulai: ${e.message}"
        }
        addressText.text = "Alamat untuk iPad:\nhttp://${getLocalIpAddress() ?: "IP belum tersedia"}:8765"
        if (hasCameraPermission()) startCamera() else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
        }
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(android.graphics.Color.rgb(23, 21, 33))
        }
        val title = TextView(this).apply {
            text = "SNAP! CAMERA BRIDGE"
            textSize = 22f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "Menyiapkan kamera..."
            textSize = 14f
            setTextColor(android.graphics.Color.rgb(160, 225, 190))
            gravity = Gravity.CENTER
            setPadding(8, 14, 8, 10)
        }
        addressText = TextView(this).apply {
            textSize = 15f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 18)
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        val note = TextView(this).apply {
            text = "1. Sambungkan Samsung dan iPad ke Wi-Fi yang sama.\n2. Biarkan aplikasi ini tetap terbuka.\n3. Masukkan alamat di atas ke panel Camera Bridge SNAP! BOOTH di iPad."
            textSize = 13f
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(4, 18, 4, 4)
        }
        layout.addView(title)
        layout.addView(statusText)
        layout.addView(addressText)
        layout.addView(previewView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        layout.addView(note)
        setContentView(layout)
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { image ->
                try {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    // CameraX YUV frames are converted to JPEG through the helper.
                    frameStore.offer(YuvJpeg.convert(image))
                } catch (_: Exception) {
                } finally {
                    image.close()
                }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageCapture,
                    analysis
                )
                CaptureRegistry.ready = true
                statusText.text = "KAMERA AKTIF · REAR CAMERA"
            } catch (e: Exception) {
                statusText.text = "Tidak bisa membuka kamera: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    fun captureJpeg(onResult: (ByteArray?) -> Unit) {
        val capture = imageCapture ?: run { onResult(null); return }
        val file = cacheDir.resolve("snap_capture_${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(output, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val bytes = try { file.readBytes() } catch (_: Exception) { null }
                file.delete()
                onResult(bytes)
            }
            override fun onError(exception: ImageCaptureException) {
                onResult(null)
            }
        })
    }

    private fun getLocalIpAddress(): String? {
        return try {
            java.util.Collections.list(NetworkInterface.getNetworkInterfaces())
                .flatMap { java.util.Collections.list(it.inetAddresses) }
                .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }
                ?.hostAddress
        } catch (_: Exception) { null }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else Toast.makeText(this, "Izin kamera diperlukan.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        CaptureRegistry.handler = null
        CaptureRegistry.ready = false
        try { server.stop() } catch (_: Exception) {}
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}

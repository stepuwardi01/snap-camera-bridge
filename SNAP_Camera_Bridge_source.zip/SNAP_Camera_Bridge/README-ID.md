# SNAP! Camera Bridge — Android MVP source

Ini adalah proyek sumber aplikasi Android pendamping SNAP! BOOTH V20. Proyek ini disiapkan agar APK dapat dibangun lewat GitHub Actions, jadi pengguna tidak perlu memasang Android Studio di laptop.

## Status penting
Ini **starter MVP/source project**, bukan APK yang sudah diuji di Samsung A56. Perlu build dan pengujian perangkat nyata sebelum dipakai di acara. Preview MJPEG dan kompatibilitas jaringan Safari harus dites; jika preview tidak stabil, tahap berikutnya adalah menggantinya dengan WebRTC.

## Kontrak yang diharapkan SNAP! BOOTH V20
- `GET http://IP-SAMSUNG:8765/api/status`
- `GET http://IP-SAMSUNG:8765/api/preview.mjpg`
- `POST http://IP-SAMSUNG:8765/api/capture`

## Cara build tanpa laptop
1. Ekstrak ZIP ini di Samsung A56 menggunakan aplikasi My Files.
2. Buat repository baru di GitHub melalui browser: https://github.com/new
3. Upload isi folder proyek (bukan file ZIP) ke repository, termasuk folder `.github/workflows`.
4. Buka tab **Actions** di repository.
5. Jalankan workflow **Build SNAP Camera Bridge APK** atau tunggu build otomatis selesai.
6. Buka hasil workflow yang sukses, unduh artifact `SNAP-Camera-Bridge-debug`.
7. Ekstrak artifact ZIP, lalu instal `app-debug.apk` di Samsung.
8. Jika Android meminta izin instalasi dari sumber tersebut, izinkan hanya untuk browser/file manager yang kamu gunakan. Instal hanya APK hasil build repository milikmu sendiri.

## Cara pakai setelah APK terpasang
1. Sambungkan Samsung dan iPad ke Wi-Fi yang sama.
2. Buka SNAP! Camera Bridge di Samsung.
3. Izinkan akses kamera.
4. Pastikan alamat IP dan port `8765` muncul di layar.
5. Biarkan aplikasi tetap terbuka.
6. Di iPad, buka SNAP! BOOTH V20 dan masukkan alamat lengkap, misalnya `http://192.168.1.20:8765`.
7. Tekan Hubungkan.

## Batasan MVP
- Kamera belakang dipilih otomatis.
- Server HTTP lokal tidak memakai autentikasi. Gunakan hanya di Wi-Fi privat yang dipercaya; jangan gunakan jaringan publik.
- Android dapat menghentikan aplikasi/server saat layar terkunci atau sistem menghemat baterai. Untuk uji coba, biarkan aplikasi terbuka dan layar menyala.
- File ini adalah fondasi pengembangan; beberapa bagian perlu verifikasi/build-fix dan pengujian pada perangkat sebenarnya sebelum dianggap siap produksi.

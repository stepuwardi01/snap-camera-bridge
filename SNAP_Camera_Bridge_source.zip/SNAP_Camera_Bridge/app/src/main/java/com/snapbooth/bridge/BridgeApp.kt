package com.snapbooth.bridge

// Kept as a separate file to make the bridge's capture callback easy to locate.

package com.snapbooth.bridge

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

object YuvJpeg {
    // CameraX is configured to deliver RGBA_8888 for ImageAnalysis.
    fun convert(image: ImageProxy): ByteArray {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val paddedBitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        paddedBitmap.copyPixelsFromBuffer(buffer)

        val bitmap = Bitmap.createBitmap(paddedBitmap, 0, 0, image.width, image.height)
        if (bitmap !== paddedBitmap) paddedBitmap.recycle()

        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 65, out)
        bitmap.recycle()
        return out.toByteArray()
    }
}

package com.snapbooth.bridge

import fi.iki.elonen.NanoHTTPD
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class LatestFrameStore {
    @Volatile private var latest: ByteArray? = null
    fun offer(bytes: ByteArray?) { if (bytes != null) latest = bytes }
    fun get(): ByteArray? = latest
}

class BridgeHttpServer(
    port: Int,
    private val frames: LatestFrameStore,
    private val ui: ((() -> Unit) -> Unit)
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        val path = session.uri
        if (session.method == Method.OPTIONS) {
            return cors(newFixedLengthResponse(Response.Status.OK, "text/plain", ""))
        }
        return when {
            path == "/api/status" && session.method == Method.GET -> {
                val ready = CaptureRegistry.ready
                val body = """{"ok":true,"ready":$ready,"device":"Samsung A56","camera":"rear"}"""
                cors(newFixedLengthResponse(Response.Status.OK, "application/json", body))
            }
            path == "/api/preview.mjpg" && session.method == Method.GET -> {
                val stream = MjpegStream(frames)
                cors(newChunkedResponse(Response.Status.OK, "multipart/x-mixed-replace; boundary=frame", stream))
            }
            path == "/api/capture" && session.method == Method.POST -> {
                // Capture is delegated to the Activity through a callback installed below.
                val bytes = CaptureRegistry.capture()
                if (bytes == null) cors(newFixedLengthResponse(Response.Status.SERVICE_UNAVAILABLE, "text/plain", "Capture unavailable"))
                else cors(newFixedLengthResponse(Response.Status.OK, "image/jpeg", ByteArrayInputStream(bytes), bytes.size.toLong()))
            }
            else -> cors(newFixedLengthResponse(Response.Status.NOT_FOUND, "application/json", """{"ok":false,"message":"Not found"}"""))
        }
    }

    private fun cors(response: Response): Response {
        response.addHeader("Access-Control-Allow-Origin", "*")
        response.addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        response.addHeader("Access-Control-Allow-Headers", "Content-Type")
        response.addHeader("Cache-Control", "no-store")
        return response
    }
}

object CaptureRegistry {
    @Volatile var ready: Boolean = false
    @Volatile var handler: (((ByteArray?) -> Unit) -> Unit)? = null
    fun capture(): ByteArray? {
        if (!ready) return null
        val latch = java.util.concurrent.CountDownLatch(1)
        var result: ByteArray? = null
        handler?.invoke { bytes -> result = bytes; latch.countDown() } ?: return null
        return if (latch.await(15, TimeUnit.SECONDS)) result else null
    }
}

private class MjpegStream(private val frames: LatestFrameStore) : InputStream() {
    private var current = ByteArray(0)
    private var index = 0
    private var closed = false

    override fun read(): Int {
        val one = ByteArray(1)
        val n = read(one, 0, 1)
        return if (n <= 0) -1 else one[0].toInt() and 0xff
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (closed) return -1
        if (index >= current.size) {
            val jpeg = frames.get() ?: run { Thread.sleep(80); return 0 }
            val header = "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${jpeg.size}\r\n\r\n".toByteArray()
            current = header + jpeg + "\r\n".toByteArray()
            index = 0
        }
        val count = minOf(len, current.size - index)
        System.arraycopy(current, index, b, off, count)
        index += count
        return count
    }

    override fun close() { closed = true }
}
